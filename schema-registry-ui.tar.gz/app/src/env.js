var ENV = {
  BASE_URL: "http://localhost:8081"
  //BASE_URL: "http://schema_registry.landoop.com:28081"
};
